﻿Public Class CapturaBoletasPorLotes
    Inherits Tarjeta
    Public Idboleta As Integer
    Public Bruto As Double
    Public Tara As Double
    Public Total As Double
End Class
