﻿Public Class LiquidacionesPorRomaneaje
    Inherits Tarjeta
    Public IdLiquidacion As Integer
    Public IdOrdenTrabajo As Integer
    Public Fecha As Date
    Public Comentarios As String
    Public IdEstatus As Integer


End Class
